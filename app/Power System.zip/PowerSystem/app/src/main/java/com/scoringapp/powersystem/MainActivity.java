package com.scoringapp.powersystem;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.ToggleButton;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private DatabaseReference mDatabase;
    private boolean isDeviceOn = false;
    private boolean isRelay1On = false;
    private boolean isRelay2On = false;
    private boolean isRelay3On = false;
    private boolean isRelay4On = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        mDatabase = database.getReference("devices").child("device1");

        // Read the current state of the device from Firebase
        mDatabase.child("state").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Boolean state = dataSnapshot.getValue(Boolean.class);
                    if (state != null) {
                        isDeviceOn = state;
//                        updateButtonText();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle any errors
            }
        });
    }

    public void toggleRelay1(View view) {
        isRelay1On = !isRelay1On;
        updateToggleButtonState((ToggleButton) view, isRelay1On);
        mDatabase.child("relay1").setValue(isRelay1On);
    }

    public void toggleRelay2(View view) {
        isRelay2On = !isRelay2On;
        updateToggleButtonState((ToggleButton) view, isRelay2On);
        mDatabase.child("relay2").setValue(isRelay2On);
    }

    public void toggleRelay3(View view) {
        isRelay3On = !isRelay3On;
        updateToggleButtonState((ToggleButton) view, isRelay3On);
        mDatabase.child("relay3").setValue(isRelay3On);
    }

    public void toggleRelay4(View view) {
        isRelay4On = !isRelay4On;
        updateToggleButtonState((ToggleButton) view, isRelay4On);
        mDatabase.child("relay4").setValue(isRelay4On);
    }

//    private void updateButtonText() {
//        Button controlButton = findViewById(R.id.controlButton);
//        controlButton.setText(isDeviceOn ? "Turn Off" : "Turn On");
//    }

    private void updateToggleButtonState(ToggleButton button, boolean state) {
        button.setChecked(state);
    }
}



