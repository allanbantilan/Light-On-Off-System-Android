//package com.scoringapp.powersystem;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.MenuItem;
//import androidx.annotation.NonNull;
//import com.google.android.material.navigation.NavigationView;
//import androidx.core.view.GravityCompat;
//import androidx.drawerlayout.widget.DrawerLayout;
//import androidx.appcompat.app.ActionBarDrawerToggle;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;
//import androidx.appcompat.app.ActionBarDrawerToggle;
//import androidx.drawerlayout.widget.DrawerLayout;
//import com.google.android.material.navigation.NavigationView;
//
//
//public class dashboard extends AppCompatActivity {
//
//    private DrawerLayout drawerLayout;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.dashboard);
//
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout); // Make sure to use R.id.drawer_layout
//
//        NavigationView navigationView = findViewById(R.id.nav_view);
//
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
//                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawerLayout.addDrawerListener(toggle);
//        toggle.syncState();
//
//
//        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//                int id = menuItem.getItemId();
//                // Handle item selections here
//                if (id == R.id.menu_item1) {
//                    // Handle the first menu item
//                } else if (id == R.id.menu_item2) {
//                    // Handle the second menu item
//                }
//
//                drawerLayout.closeDrawer(GravityCompat.START);
//                return true;
//            }
//        });
//    }
//}
